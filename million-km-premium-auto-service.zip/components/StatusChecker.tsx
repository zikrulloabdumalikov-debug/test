
import React, { useState } from 'react';
import { CAR_DATA } from '../constants';

interface StatusCheckerProps {
  showToast: (msg: string, type: any) => void;
}

const StatusChecker: React.FC<StatusCheckerProps> = ({ showToast }) => {
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [year, setYear] = useState('');
  const [km, setKm] = useState('');
  const [result, setResult] = useState<{ status: 'eligible' | 'not_eligible' | null; message: string }>({ status: null, message: '' });

  const handleCheck = () => {
    if (!brand || !model || !year || !km) {
      showToast("Iltimos, barcha maydonlarni to'ldiring", "error");
      return;
    }

    const currentYear = new Date().getFullYear();
    const carAge = currentYear - parseInt(year);
    const carKm = parseInt(km);
    const limits = CAR_DATA[brand]?.[model];

    if (!limits) {
      setResult({ status: 'not_eligible', message: "Kechirasiz, ushbu model uchun dastur hali ishga tushmagan." });
      return;
    }

    if (carAge <= limits.maxAge && carKm <= limits.maxKm) {
      setResult({ 
        status: 'eligible', 
        message: `Tabriklaymiz! Sizning mashinangiz dasturga mos keladi. Max Age: ${limits.maxAge}, Sizda: ${carAge}. Max Km: ${limits.maxKm}, Sizda: ${carKm}.` 
      });
    } else {
      setResult({ 
        status: 'not_eligible', 
        message: "Afsuski, limitlar oshib ketgan. Lekin siz bir martalik servis xizmatimizdan foydalanishingiz mumkin." 
      });
    }
  };

  return (
    <div className="bg-white rounded-[2rem] p-8 md:p-12 shadow-xl border border-gray-100">
      <div className="max-w-3xl mx-auto text-center mb-10">
        <h2 className="text-3xl font-bold mb-4">Mashinangiz statusini tekshiring</h2>
        <p className="text-slate-500">Kafolat dasturiga mos kelishingizni 3 soniyada aniqlang.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <div className="space-y-4">
          <label className="block">
            <span className="text-sm font-bold text-slate-700 ml-1">Brend</span>
            <select 
              className="mt-1 block w-full px-4 py-3 rounded-xl bg-gray-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all"
              value={brand}
              onChange={(e) => { setBrand(e.target.value); setModel(''); }}
            >
              <option value="">Tanlang</option>
              {Object.keys(CAR_DATA).map(b => <option key={b} value={b}>{b.toUpperCase()}</option>)}
            </select>
          </label>

          <label className="block">
            <span className="text-sm font-bold text-slate-700 ml-1">Model</span>
            <select 
              className="mt-1 block w-full px-4 py-3 rounded-xl bg-gray-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all"
              disabled={!brand}
              value={model}
              onChange={(e) => setModel(e.target.value)}
            >
              <option value="">Brendni tanlang</option>
              {brand && Object.keys(CAR_DATA[brand]).map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </label>
        </div>

        <div className="space-y-4">
          <label className="block">
            <span className="text-sm font-bold text-slate-700 ml-1">Ishlab chiqarilgan yili</span>
            <input 
              type="number" 
              className="mt-1 block w-full px-4 py-3 rounded-xl bg-gray-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all"
              placeholder="Masalan: 2022"
              value={year}
              onChange={(e) => setYear(e.target.value)}
            />
          </label>
          <label className="block">
            <span className="text-sm font-bold text-slate-700 ml-1">Yurgan masofasi (km)</span>
            <input 
              type="number" 
              className="mt-1 block w-full px-4 py-3 rounded-xl bg-gray-50 border-transparent focus:border-blue-500 focus:bg-white focus:ring-0 transition-all"
              placeholder="Masalan: 45000"
              value={km}
              onChange={(e) => setKm(e.target.value)}
            />
          </label>
        </div>
      </div>

      <div className="mt-10 text-center">
        <button 
          onClick={handleCheck}
          className="px-12 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all shadow-lg"
        >
          Tekshirish
        </button>
      </div>

      {result.status && (
        <div className={`mt-10 p-8 rounded-3xl animate-in fade-in zoom-in duration-300 ${result.status === 'eligible' ? 'bg-green-50 border border-green-100' : 'bg-red-50 border border-red-100'}`}>
          <div className="flex items-center space-x-4 mb-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white ${result.status === 'eligible' ? 'bg-green-500' : 'bg-red-500'}`}>
              <i className={`fas ${result.status === 'eligible' ? 'fa-check' : 'fa-times'} text-xl`}></i>
            </div>
            <h3 className={`text-xl font-bold ${result.status === 'eligible' ? 'text-green-800' : 'text-red-800'}`}>
              {result.status === 'eligible' ? 'Xushxabar!' : 'Afsuski...'}
            </h3>
          </div>
          <p className="text-slate-700 leading-relaxed mb-6">{result.message}</p>
          <button className={`px-6 py-3 rounded-xl font-bold text-sm transition-all ${result.status === 'eligible' ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-red-600 text-white hover:bg-red-700'}`}>
            {result.status === 'eligible' ? "Ro'yxatdan o'tish" : "Bir martalik xizmat buyurtma qilish"}
          </button>
        </div>
      )}
    </div>
  );
};

export default StatusChecker;
