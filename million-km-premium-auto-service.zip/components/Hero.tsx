
import React from 'react';

interface HeroProps {
  onStart: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStart }) => {
  return (
    <div className="relative pt-24 pb-20 overflow-hidden">
      {/* Dynamic Background Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-[10%] left-[-10%] w-[500px] h-[500px] bg-blue-100/40 rounded-full blur-[120px] animate-subtle"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-slate-100/50 rounded-full blur-[140px] animate-subtle" style={{animationDelay: '1s'}}></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 text-center">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-white border border-slate-100 shadow-sm mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <span className="flex h-2 w-2 rounded-full bg-blue-600"></span>
          <span className="text-[10px] font-bold text-slate-500 tracking-[0.2em] uppercase">Premium Automotive Intelligence</span>
        </div>
        
        <h1 className="text-5xl md:text-8xl font-black tracking-tight text-slate-900 mb-10 leading-[1.1] animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
          Dvigatel uchun <br />
          <span className="text-blue-600 italic font-serif">xotirjamlik.</span>
        </h1>
        
        <p className="text-lg md:text-xl text-slate-500 max-w-2xl mx-auto mb-14 font-medium leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
          O'zbekistondagi ilk va yagona million kilometrgacha texnik kafolat dasturi. Mashinangiz umrini biz bilan uzaytiring.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-300">
          <button 
            onClick={onStart}
            className="w-full sm:w-auto px-10 py-5 bg-slate-900 text-white rounded-[1.5rem] font-bold text-lg shadow-2xl shadow-slate-200 hover:bg-blue-600 hover:-translate-y-1 transition-all active:scale-95"
          >
            Hozir boshlash
          </button>
          <button 
            onClick={() => document.getElementById('status')?.scrollIntoView({ behavior: 'smooth' })}
            className="w-full sm:w-auto px-10 py-5 bg-white text-slate-900 rounded-[1.5rem] font-bold text-lg border border-slate-100 hover:bg-slate-50 transition-all flex items-center justify-center"
          >
            <i className="fas fa-shield-alt mr-2 text-blue-500"></i>
            Dasturni tekshirish
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
