
import React, { useState } from 'react';
import { User } from '../types';

interface NavbarProps {
  currentView: string;
  setView: (view: any) => void;
  user: User | null;
  onLogout: () => void;
  onLoginClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView, user, onLogout, onLoginClick }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Bosh sahifa', view: 'home', icon: 'fa-home' },
    { label: 'Express', view: 'express', icon: 'fa-bolt' },
    { label: 'Fuel', view: 'fuel', icon: 'fa-gas-pump' },
  ];

  return (
    <nav className="fixed top-0 w-full z-40 glass border-b border-gray-200/50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div 
            className="flex-shrink-0 cursor-pointer flex items-center space-x-2"
            onClick={() => setView('home')}
          >
            <div className="bg-blue-600 text-white w-10 h-10 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
              <i className="fas fa-car-side text-lg"></i>
            </div>
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
              Million KM
            </span>
          </div>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.view}
                onClick={() => setView(link.view)}
                className={`text-sm font-medium transition-all hover:text-blue-600 ${currentView === link.view ? 'text-blue-600' : 'text-slate-500'}`}
              >
                {link.label}
              </button>
            ))}
            
            <div className="h-6 w-px bg-gray-200 mx-2"></div>

            {user ? (
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => setView('cabinet')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${currentView === 'cabinet' ? 'bg-blue-600 text-white shadow-md' : 'bg-gray-100 text-slate-700 hover:bg-gray-200'}`}
                >
                  <i className="fas fa-user-circle"></i>
                  <span className="text-sm font-semibold">{user.name}</span>
                </button>
                {user.isAdmin && (
                   <button 
                    onClick={() => setView('admin')}
                    className={`p-2 rounded-full transition-all ${currentView === 'admin' ? 'bg-slate-900 text-white' : 'text-slate-500 hover:bg-gray-100'}`}
                    title="Admin Panel"
                   >
                     <i className="fas fa-cog"></i>
                   </button>
                )}
                <button onClick={onLogout} className="text-slate-400 hover:text-red-500 transition-colors p-2">
                  <i className="fas fa-sign-out-alt"></i>
                </button>
              </div>
            ) : (
              <button 
                onClick={onLoginClick}
                className="bg-slate-900 text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
              >
                Kirish
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-slate-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-gray-100 animate-in slide-in-from-top duration-200">
          <div className="px-4 py-6 space-y-4">
            {navLinks.map((link) => (
              <button
                key={link.view}
                onClick={() => { setView(link.view); setIsMenuOpen(false); }}
                className="flex items-center space-x-4 w-full px-4 py-3 rounded-xl text-left hover:bg-gray-50 transition-colors"
              >
                <i className={`fas ${link.icon} text-blue-500 w-6`}></i>
                <span className="font-medium text-slate-700">{link.label}</span>
              </button>
            ))}
            {user && (
              <button
                onClick={() => { setView('cabinet'); setIsMenuOpen(false); }}
                className="flex items-center space-x-4 w-full px-4 py-3 rounded-xl text-left hover:bg-gray-50 transition-colors"
              >
                <i className="fas fa-user-circle text-blue-500 w-6"></i>
                <span className="font-medium text-slate-700">Shaxsiy kabinet</span>
              </button>
            )}
            <div className="pt-4">
              {!user ? (
                <button 
                  onClick={() => { onLoginClick(); setIsMenuOpen(false); }}
                  className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold"
                >
                  Kirish
                </button>
              ) : (
                <button 
                  onClick={() => { onLogout(); setIsMenuOpen(false); }}
                  className="w-full border border-red-100 text-red-500 py-3 rounded-xl font-bold hover:bg-red-50"
                >
                  Chiqish
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
