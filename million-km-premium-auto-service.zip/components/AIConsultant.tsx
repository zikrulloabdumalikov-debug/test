
import React, { useState } from 'react';
import { getCarAdvice } from '../services/geminiService';

const AIConsultant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [model, setModel] = useState('');
  const [problem, setProblem] = useState('');
  const [advice, setAdvice] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAsk = async () => {
    if (!model || !problem) return;
    setIsLoading(true);
    const result = await getCarAdvice(model, problem);
    setAdvice(result);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-6 left-6 z-40">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 bg-slate-900 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all group"
        >
          <i className="fas fa-robot text-xl"></i>
          <span className="absolute left-16 bg-slate-900 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">AI Maslahatchi</span>
        </button>
      ) : (
        <div className="w-80 md:w-96 bg-white rounded-3xl shadow-2xl border border-gray-100 flex flex-col animate-in slide-in-from-left duration-300">
          <div className="p-4 bg-slate-900 text-white rounded-t-3xl flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <i className="fas fa-microchip text-blue-400"></i>
              <span className="font-bold">AI Mexanik</span>
            </div>
            <button onClick={() => setIsOpen(false)}><i className="fas fa-times"></i></button>
          </div>
          
          <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            {!advice ? (
              <>
                <p className="text-sm text-slate-500">Mashinangizdagi muammo haqida yozing, AI mexanik sizga texnik maslahat beradi.</p>
                <input 
                  className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500" 
                  placeholder="Mashina modeli (Masalan: Cobalt)" 
                  value={model}
                  onChange={e => setModel(e.target.value)}
                />
                <textarea 
                  className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm focus:ring-2 focus:ring-blue-500 min-h-[80px]" 
                  placeholder="Muammo nima? (Masalan: Motor shovqin qilyapti)"
                  value={problem}
                  onChange={e => setProblem(e.target.value)}
                />
                <button 
                  onClick={handleAsk}
                  disabled={isLoading}
                  className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-blue-100 flex items-center justify-center disabled:opacity-50"
                >
                  {isLoading ? <i className="fas fa-circle-notch fa-spin"></i> : "Maslahat olish"}
                </button>
              </>
            ) : (
              <div className="space-y-4 animate-in fade-in duration-500">
                <div className="bg-blue-50 p-4 rounded-2xl">
                  <p className="text-sm text-blue-800 leading-relaxed italic">"{advice}"</p>
                </div>
                <button 
                  onClick={() => { setAdvice(''); setProblem(''); }}
                  className="w-full py-3 bg-gray-100 text-slate-600 rounded-xl font-bold text-sm"
                >
                  Yana so'rash
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AIConsultant;
