
import React, { useState } from 'react';
import { CAR_DATA, ONE_TIME_SERVICES, YEARLY_BENEFITS } from '../constants';
import { User, Order } from '../types';

interface BrandGridProps {
  user: User | null;
  onOrder: (order: Partial<Order>) => void;
  onOpenAuth: () => void;
}

const BrandGrid: React.FC<BrandGridProps> = ({ user, onOrder, onOpenAuth }) => {
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [activeInfoModal, setActiveInfoModal] = useState(false);

  const brands = Object.keys(CAR_DATA);

  const handleOrder = (model: string, price: number) => {
    if (!user) {
      onOpenAuth();
      return;
    }
    onOrder({
      brand: selectedBrand || 'Unknown',
      model: model,
      serviceType: 'One-time Service',
      note: `Narxi: ${price.toLocaleString()} so'm`
    });
  };

  return (
    <div className="space-y-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="max-w-xl">
          <h2 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">Biz qamrab olgan brendlar</h2>
          <p className="text-slate-500 text-lg">Hozirda biz eng ishonchli va ommabop brendlar uchun premium xizmat ko'rsatamiz.</p>
        </div>
        <button 
          onClick={() => setActiveInfoModal(true)}
          className="flex items-center space-x-2 text-blue-600 font-bold hover:text-blue-700 transition-colors"
        >
          <i className="fas fa-info-circle"></i>
          <span>Xizmat paketi tarkibi</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {brands.map((brand) => (
          <div 
            key={brand}
            onClick={() => setSelectedBrand(brand)}
            className={`group relative cursor-pointer p-10 rounded-[2.5rem] border-2 transition-all duration-500 ${selectedBrand === brand ? 'border-blue-600 bg-white shadow-2xl ring-4 ring-blue-50' : 'border-transparent bg-white shadow-lg hover:shadow-2xl hover:translate-y-[-8px]'}`}
          >
            <div className={`w-20 h-20 rounded-3xl mb-8 flex items-center justify-center text-4xl transition-all duration-500 ${selectedBrand === brand ? 'bg-blue-600 text-white shadow-xl shadow-blue-200' : 'bg-gray-50 text-slate-300 group-hover:bg-slate-100 group-hover:text-slate-500'}`}>
               <i className={`fas ${brand === 'chevrolet' ? 'fa-car-side' : brand === 'kia' ? 'fa-car' : 'fa-bolt'}`}></i>
            </div>
            <h3 className="text-3xl font-extrabold mb-3 capitalize text-slate-900 tracking-tight">{brand}</h3>
            <p className="text-slate-500 font-medium mb-8">Million KM kafolati va yuqori darajadagi texnik ko'rik.</p>
            <div className={`flex items-center font-bold text-sm uppercase tracking-widest ${selectedBrand === brand ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-900'}`}>
              <span>Modellarni tanlash</span>
              <i className="fas fa-chevron-right ml-3 transition-transform group-hover:translate-x-2"></i>
            </div>
          </div>
        ))}
      </div>

      {selectedBrand && (
        <div className="mt-12 p-10 md:p-16 bg-slate-900 rounded-[3.5rem] text-white animate-in slide-in-from-bottom-12 duration-700">
          <div className="flex items-center justify-between mb-12">
            <div>
              <span className="text-blue-400 font-bold uppercase tracking-widest text-xs mb-2 block">Tanlangan Brend</span>
              <h3 className="text-4xl font-extrabold capitalize">{selectedBrand} Modellari</h3>
            </div>
            <button 
                onClick={() => setSelectedBrand(null)}
                className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
            >
                <i className="fas fa-times"></i>
            </button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Object.entries(CAR_DATA[selectedBrand]).map(([model, info]) => (
              <div key={model} className="bg-white/5 backdrop-blur-md p-10 rounded-[2.5rem] border border-white/10 hover:bg-white/10 transition-all flex flex-col h-full">
                <h4 className="text-2xl font-bold mb-4">{model}</h4>
                <div className="flex flex-wrap gap-3 mb-6">
                  <span className="text-[10px] px-3 py-1.5 rounded-full bg-blue-500/20 text-blue-400 font-bold uppercase tracking-widest">Max {info.maxAge} YIL</span>
                  <span className="text-[10px] px-3 py-1.5 rounded-full bg-blue-500/20 text-blue-400 font-bold uppercase tracking-widest">Max {info.maxKm.toLocaleString()} KM</span>
                </div>
                <p className="text-white/60 text-sm mb-10 leading-relaxed flex-grow">{info.desc}</p>
                <div className="bg-white/10 p-6 rounded-2xl mb-8">
                  <div className="text-[10px] text-white/40 font-bold uppercase tracking-widest mb-2">Servis narxi</div>
                  <div className="text-2xl font-black text-white">
                    {info.priceOneTime ? info.priceOneTime.toLocaleString() + " SO'M" : "Tez kunda"}
                  </div>
                </div>
                <button 
                  onClick={() => handleOrder(model, info.priceOneTime || 0)}
                  className="w-full py-5 bg-white text-slate-900 rounded-2xl font-black uppercase tracking-wider text-sm hover:bg-blue-500 hover:text-white transition-all active:scale-95 shadow-xl"
                >
                  Buyurtma berish
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeInfoModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/80 backdrop-blur-md p-4">
          <div className="bg-white rounded-[3rem] p-10 md:p-16 w-full max-w-4xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button onClick={() => setActiveInfoModal(false)} className="absolute top-10 right-10 text-slate-400 hover:text-slate-900">
              <i className="fas fa-times text-2xl"></i>
            </button>
            <h2 className="text-4xl font-extrabold mb-12 text-slate-900 tracking-tight">Xizmatlar nimalarni o'z ichiga oladi?</h2>
            
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h4 className="text-xl font-bold mb-8 flex items-center text-blue-600">
                  <i className="fas fa-tools mr-3"></i> Bir martalik servis
                </h4>
                <ul className="space-y-4">
                  {ONE_TIME_SERVICES.map((s, idx) => (
                    <li key={idx} className="flex items-start space-x-3 text-slate-600 font-medium">
                      <i className="fas fa-check-circle text-blue-500 mt-1"></i>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-slate-50 p-10 rounded-[2.5rem] border border-slate-100">
                <h4 className="text-xl font-bold mb-8 flex items-center text-indigo-600">
                  <i className="fas fa-star mr-3"></i> Yillik kafolat (Premium)
                </h4>
                <ul className="space-y-4">
                  {YEARLY_BENEFITS.map((b, idx) => (
                    <li key={idx} className="flex items-start space-x-3 text-slate-600 font-medium">
                      <i className="fas fa-gift text-indigo-500 mt-1"></i>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-10 p-4 bg-indigo-600 rounded-2xl text-white text-center font-bold text-sm">
                  Dvigatel uchun to'liq xotirjamlik!
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BrandGrid;
