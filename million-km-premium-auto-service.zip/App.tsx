
import React, { useState, useEffect, useCallback } from 'react';
import { User, Car, Order } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import StatusChecker from './components/StatusChecker';
import BrandGrid from './components/BrandGrid';
import Cabinet from './components/Cabinet';
import Admin from './components/Admin';
import MobileService from './components/MobileService';
import AIConsultant from './components/AIConsultant';

type View = 'home' | 'cabinet' | 'admin' | 'express' | 'fuel';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  useEffect(() => {
    const savedUser = localStorage.getItem('million_km_user');
    const savedOrders = localStorage.getItem('million_km_orders');
    if (savedUser) setCurrentUser(JSON.parse(savedUser));
    if (savedOrders) setOrders(JSON.parse(savedOrders));
  }, []);

  const addOrder = (orderData: Partial<Order>) => {
    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9),
      userName: orderData.userName || currentUser?.name || 'Mehmon',
      brand: orderData.brand || 'Nomaʼlum',
      model: orderData.model || 'Nomaʼlum',
      serviceType: orderData.serviceType || 'Servis',
      phone: orderData.phone || currentUser?.phone || '',
      note: orderData.note,
      timestamp: new Date().toLocaleString('uz-UZ'),
    };
    const updated = [newOrder, ...orders];
    setOrders(updated);
    localStorage.setItem('million_km_orders', JSON.stringify(updated));
    showToast("Buyurtmangiz qabul qilindi!", "success");
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('million_km_user', JSON.stringify(user));
    setIsAuthModalOpen(false);
    showToast(`Xush kelibsiz, ${user.name}!`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('million_km_user');
    setCurrentView('home');
    showToast("Tizimdan chiqdingiz.");
  };

  const renderView = () => {
    switch (currentView) {
      case 'cabinet':
        return currentUser ? <Cabinet user={currentUser} showToast={showToast} onOrder={addOrder} /> : <Hero onStart={() => setIsAuthModalOpen(true)} />;
      case 'admin':
        return currentUser?.isAdmin ? <Admin orders={orders} /> : <div className="p-20 text-center font-bold text-red-500">Ruxsat yo'q</div>;
      case 'express':
      case 'fuel':
        return <MobileService type={currentView} user={currentUser} onOrder={addOrder} onOpenAuth={() => setIsAuthModalOpen(true)} />;
      default:
        return (
          <div className="animate-in fade-in duration-700">
            <Hero onStart={() => document.getElementById('brands')?.scrollIntoView({ behavior: 'smooth' })} />
            <div id="status" className="max-w-7xl mx-auto px-4 py-16">
               <StatusChecker showToast={showToast} />
            </div>
            <div id="brands" className="max-w-7xl mx-auto px-4 py-16">
              <BrandGrid user={currentUser} onOrder={addOrder} onOpenAuth={() => setIsAuthModalOpen(true)} />
            </div>
            <AIConsultant />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-blue-100 selection:text-blue-900">
      <Navbar 
        currentView={currentView} 
        setView={setCurrentView} 
        user={currentUser} 
        onLogout={handleLogout} 
        onLoginClick={() => setIsAuthModalOpen(true)} 
      />
      
      <main className="flex-grow pt-20">
        {renderView()}
      </main>

      <footer className="bg-white border-t border-slate-100 py-20 mt-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-12 gap-12">
            <div className="md:col-span-5">
              <div className="text-2xl font-extrabold mb-6 tracking-tighter">Million KM</div>
              <p className="text-slate-500 max-w-sm leading-relaxed mb-8">
                O'zbekistondagi ilk premium avtoservis tarmog'i. Dvigatelingiz uchun yangi avlod ishonchi.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-blue-600 hover:text-white transition-all"><i className="fab fa-telegram"></i></a>
                <a href="#" className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-400 hover:bg-pink-500 hover:text-white transition-all"><i className="fab fa-instagram"></i></a>
              </div>
            </div>
            <div className="md:col-span-7 grid grid-cols-2 md:grid-cols-3 gap-8">
              <div>
                <h4 className="font-bold text-slate-900 mb-6 uppercase text-xs tracking-widest">Platforma</h4>
                <ul className="space-y-4 text-slate-500 text-sm font-medium">
                  <li><button onClick={() => setCurrentView('home')} className="hover:text-blue-600">Bosh sahifa</button></li>
                  <li><button onClick={() => setCurrentView('express')} className="hover:text-blue-600">Express Servis</button></li>
                  <li><button onClick={() => setCurrentView('fuel')} className="hover:text-blue-600">Yoqilg'i yetkazish</button></li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-slate-900 mb-6 uppercase text-xs tracking-widest">Kompaniya</h4>
                <ul className="space-y-4 text-slate-500 text-sm font-medium">
                  <li><a href="#" className="hover:text-blue-600">Biz haqimizda</a></li>
                  <li><a href="#" className="hover:text-blue-600">Aloqa</a></li>
                  <li><a href="#" className="hover:text-blue-600">FAQ</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="mt-16 pt-8 border-t border-slate-50 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider">© 2024 Million KM Service. Barcha huquqlar himoyalangan.</p>
            <div className="text-xs text-slate-300 font-medium">Made with precision for Uzbekistan</div>
          </div>
        </div>
      </footer>

      {isAuthModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-[2.5rem] p-10 w-full max-w-md shadow-2xl relative animate-in zoom-in fade-in duration-300">
            <button onClick={() => setIsAuthModalOpen(false)} className="absolute top-8 right-8 text-slate-300 hover:text-slate-900 transition-colors">
              <i className="fas fa-times text-xl"></i>
            </button>
            <div className="text-center mb-10">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl mx-auto mb-6 flex items-center justify-center text-white shadow-xl shadow-blue-100">
                <i className="fas fa-fingerprint text-2xl"></i>
              </div>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Xush kelibsiz</h2>
              <p className="text-slate-500 mt-2 font-medium">Tizimga kirish uchun tanlang</p>
            </div>
            <div className="space-y-4">
               <button 
                onClick={() => handleLogin({ uid: 'u1', name: 'Sherzod Admin', email: 'admin@million.uz', phone: '+998901234567', gender: 'male', isAdmin: true })}
                className="w-full bg-slate-900 text-white py-4.5 rounded-2xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center shadow-lg"
               >
                 <i className="fas fa-user-shield mr-3 text-blue-400"></i> Admin sifatida kirish
               </button>
               <button 
                onClick={() => handleLogin({ uid: 'u2', name: 'Azizbek Mijoz', email: 'aziz@mail.uz', phone: '+998997771122', gender: 'male', isAdmin: false })}
                className="w-full border-2 border-slate-100 py-4.5 rounded-2xl font-bold text-slate-700 hover:bg-slate-50 transition-all flex items-center justify-center"
               >
                 <i className="fas fa-user mr-3 text-slate-400"></i> Mijoz sifatida kirish
               </button>
            </div>
            <p className="text-center text-[10px] text-slate-400 mt-10 uppercase tracking-[0.15em] font-bold">
              Premium Auto Care Standards
            </p>
          </div>
        </div>
      )}

      {toast && (
        <div className={`fixed bottom-10 left-1/2 -translate-x-1/2 z-[110] px-8 py-4.5 rounded-2xl shadow-2xl flex items-center space-x-4 text-white animate-in slide-in-from-bottom-12 duration-500 ${toast.type === 'success' ? 'bg-slate-900 border border-slate-800' : 'bg-red-600'}`}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${toast.type === 'success' ? 'bg-blue-500' : 'bg-white/20'}`}>
            <i className={`fas ${toast.type === 'success' ? 'fa-check' : 'fa-exclamation-triangle'} text-xs`}></i>
          </div>
          <span className="font-bold text-sm tracking-wide">{toast.message}</span>
        </div>
      )}
    </div>
  );
};

export default App;
